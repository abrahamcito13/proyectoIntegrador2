document.getElementById("icon-menu").addEventListener("click", mostrar_menu);

function mostrar_menu() {
    document.getElementById("move-content").classList.toggle('move-container-all');
    document.getElementById("show-menu").classList.toggle('show-lateral');
}

// Obtener el elemento del encabezado
var header = document.querySelector("header");
var logoHeader = document.querySelector(".logo-header");
var initialHeaderHeight = header.clientHeight;
var headerText = document.querySelector(".logo h1");

// Añadir un event listener para el desplazamiento
window.addEventListener("scroll", function () {
    var scrollPosition = window.scrollY || window.pageYOffset;

    if (scrollPosition > initialHeaderHeight) {
        header.style.height = "50px";
        logoHeader.style.display = "none";
    } else {
        header.style.height = initialHeaderHeight + "px";
        logoHeader.style.display = "block";

        headerText.style.display = "block";
        headerText.style.alignItems = "initial";
    }
});

//Enlaces de redes sociales
const enlacesRedesSociales = {
    facebook: "https://www.facebook.com/tupagina",
    whatsapp: "https://wa.me/tunumerodetelefono",
    instagram: "https://www.instagram.com/tuinstagram",
    twitter: "https://twitter.com/tutwitter"
};

//contraseña
function togglePasswordVisibility() {
    var passwordInput = document.getElementById('txtContra');
    var eyeIcon = document.querySelector('.login-container-izq button i');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    }
}

// Mostrar el mensaje de éxito al enviar el formulario
document.addEventListener('DOMContentLoaded', function () {
    var form = document.querySelector('form');
    var successMessage = document.getElementById('success-message');

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        var formData = new FormData(form);

        fetch('correo.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Hubo un error al enviar el formulario.');
            }
            successMessage.classList.remove('hidden');
            setTimeout(function() {
                successMessage.classList.add('hidden');
            }, 3000);
        })
        .catch(error => {
            alert(error.message);
        });
    });
});

document.addEventListener("DOMContentLoaded", function() {
    // Obtén los elementos <a> y actualiza sus atributos href
    document.getElementById("enlace-facebook").href = enlacesRedesSociales.facebook;
    document.getElementById("enlace-whatsapp").href = enlacesRedesSociales.whatsapp;
    document.getElementById("enlace-instagram").href = enlacesRedesSociales.instagram;
    document.getElementById("enlace-twitter").href = enlacesRedesSociales.twitter;
});
